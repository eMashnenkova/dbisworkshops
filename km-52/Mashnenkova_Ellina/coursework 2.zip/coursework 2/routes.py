# -*- coding: utf-8 -*-
from functools import wraps

from flask import Flask, render_template, session, flash, url_for, request
from werkzeug.utils import redirect

from db import Database
from forms import LoginForm, RegisterForm, RecordForm


app = Flask(__name__)
app.secret_key = 'Development key'



@app.route('/setup')
def page_setup():

    Database().init_db()
    return 'OK'



@app.route('/')
def page_index():

    return render_template('home.html')



@app.route('/about')
def page_about():

    return render_template('about.html')


# Страница регистрации
@app.route('/register', methods=['GET', 'POST'])
def page_register():

    form = RegisterForm(request.form)
    if request.method == 'POST':

        if form.validate():
            data = {
                'password': form.password.data,
                'login': form.login.data,
            }

            Database().registration(**data)

            flash('Вы успешно зарегистрировались и можете войти.', 'success')

            return redirect(url_for('page_index'))

    return render_template('register.html', form=form)


# Страница входа
@app.route('/login', methods=['GET', 'POST'])
def page_login():

    form = LoginForm(request.form)
    if request.method == 'POST':

        if form.validate():

            login = Database().authorization(login=form.login.data, password=form.password.data)
            if login is not None:

                session['logged_in'] = login

                flash('Вы успешно авторизовались.', 'success')

                return redirect(url_for('page_index'))
            else:

                flash('Пользователь не найден или пароль не подошел.', 'danger')

    return render_template('login.html', form=form)



@app.route('/logout')
def page_logout():

    session.clear()

    flash('Вы успешно вышли.', 'success')

    return redirect(url_for('page_login'))



def is_logged_in(f):
    @wraps(f)
    def wrap(*args,**kwargs):
        if 'logged_in' in session:

            return f(*args,**kwargs)
        else:

            flash('Вы не авторизованы, пожалуйста, войдите.', 'danger')
            return redirect(url_for('page_login'))
    return wrap


@app.route('/add', methods=['GET', 'POST'])
@is_logged_in
def page_add():

    form = RecordForm(request.form, owner=session['logged_in'])
    if request.method == 'POST':

        if form.validate():
            data = {
                'title': form.title.data,
                'body': form.body.data,
                'owner': form.owner.data,
                'users': form.users.data,
                'version': int(form.version.data),
            }

            _, slug = Database().add_record(**data)

            flash('Запись создана.', 'success')

            return redirect(url_for('page_record', slug=slug))

    return render_template('add.html', form=form)



@app.route('/record/<string:slug>')
@is_logged_in
def page_record(slug):

    record = Database().get_record(slug)

    names = [record['owner'], ]
    names += [r.strip() for r in record['users'].split(',') if r.strip()]

    if session['logged_in'] in names:
        return render_template('record.html', record=record)

    else:
        return redirect(url_for('page_index'))



@app.route('/documents')
def page_documents():

    slugs = Database().get_records_slugs()

    return render_template('documents.html', slugs=slugs)
