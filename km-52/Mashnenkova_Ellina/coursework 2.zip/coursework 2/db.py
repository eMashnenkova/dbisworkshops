# -*- coding: utf-8 -*-
import cx_Oracle
import pytils



DB_LOGIN = 'system'
DB_PASSWORD = 'manager'

DB_HOST = 'localhost'

DB_PORT = '1521'



class Database:
    def __init__(self):
        self.__enter__()


    def __enter__(self):
        self.__db = cx_Oracle.Connection('{}/{}@//{}:{}/xe'.format(DB_LOGIN, DB_PASSWORD, DB_HOST, DB_PORT))
        self.__cursor = self.__db.cursor()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.__cursor.close()
        self.__db.close()

    def init_db(self):

        query1 = '''
            CREATE TABLE USERS
            (
              LOGIN VARCHAR2(80)
            , PASSWORD VARCHAR2(20)
            , CONSTRAINT USERS_PK PRIMARY KEY
              (
                LOGIN
              )
              USING INDEX
              (
                  CREATE UNIQUE INDEX TABLE1_PK ON USERS (LOGIN ASC)
              )
              ENABLE
            )
        '''
        query2 = '''
            CREATE TABLE RECORDS 
            ( 
              TITLE VARCHAR2(80) 
            , BODY VARCHAR2(2560)
            , VERSION INTEGER
            , SLUG VARCHAR2(120)
            , OWNER VARCHAR2(80)
            , USERS VARCHAR2(800)
            )
        '''
        self.__cursor.execute(query1)
        self.__cursor.execute(query2)

        self.__db.commit()


    def registration(self, login, password):

        query = 'INSERT INTO USERS (LOGIN, PASSWORD) VALUES(:login, :password)'

        created = self.__cursor.execute(query, login=login, password=password)

        self.__db.commit()

        return created

    def authorization(self, login, password):

        is_user = self.__cursor.execute('''
            SELECT * FROM USERS WHERE login = '{}' AND password = '{}'
        '''.format(
            login, password,
        )).fetchone()

        return is_user and login

    def add_record(self, title, body, version, owner, users):

        slug = '{}_{}'.format(pytils.translit.slugify(title), version)
        query = '''INSERT INTO RECORDS (TITLE, BODY, VERSION, SLUG, OWNER, USERS) VALUES('{}', '{}', '{}', '{}', '{}', '{}')'''.format(
            title, body, version, slug, owner, users,
        )
        created = self.__cursor.execute(query)
        self.__db.commit()
        return created, slug

    def get_record(self, slug):

        query = 'SELECT * FROM RECORDS WHERE slug = :slug'
        record = self.__cursor.execute(query, slug=slug).fetchone()
        self.__db.commit()

        record = {
            'title': record[0],

            'body': record[1].replace('\n', '<br>'),
            'version': record[2],
            'slug': record[3],
            'owner': record[4],
            'users': record[5],
        }
        return record

    def get_records_slugs(self):

        query = 'SELECT SLUG, TITLE, VERSION FROM RECORDS'
        records = self.__cursor.execute(query).fetchall()
        return records
