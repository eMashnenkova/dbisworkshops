# -*- coding: utf-8 -*-
from wtforms import Form, validators, StringField, PasswordField, SubmitField, IntegerField
from wtforms.widgets import TextArea


# форма регистрации
class RegisterForm(Form):
    login = StringField('Логин', validators=[

        validators.Length(4, 20, 'Длина логина – от 4 до 20 символов.'),

        validators.DataRequired(),
    ])
    password = PasswordField('Пароль', validators=[
        validators.Length(4, 20, 'Длина пароля – от 4 до 20 символов.'),
        validators.DataRequired(),
    ])


# форма входа
class LoginForm(Form):
    login = StringField('Логин', validators=[
        validators.DataRequired('Пожалуйста, введите свой логин:'),
        validators.Length(4, 20, 'Длина логина – от 4 до 20 символов.'),
    ])
    password = PasswordField('Пароль', validators=[
        validators.DataRequired(),
    ])
    submit = SubmitField('Войти')


# форма создания статьи
class RecordForm(Form):
    title = StringField('Заголовок', validators=[
        validators.DataRequired('Пожалуйста, введите заголовок:'),
        validators.Length(1, 80, 'Длина заголовка – от 1 до 80 символов.'),
    ])
    body = StringField('Текст', validators=[
        validators.DataRequired('Пожалуйста, введите текст статьи:'),
        validators.Length(1, 2560, 'Длина текста – от 1 до 2560 символов.'),
    ], widget=TextArea())

    owner = StringField('Логин владельца', validators=[
        validators.DataRequired('Необходимо указать владельца статьи.'),
    ])
    users = StringField(
        'Логины пользователей, которые могут просматривать документы (через запятую)',

        default='',
    )
    version = IntegerField('Версия')
